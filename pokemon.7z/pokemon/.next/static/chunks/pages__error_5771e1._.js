(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages__error_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages__error_5771e1._.js",
  "chunks": [
    "static/chunks/[root of the server]__31723f._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_beb007._.js",
    "static/chunks/[root of the server]__2e1cf5._.js"
  ],
  "source": "entry"
});
