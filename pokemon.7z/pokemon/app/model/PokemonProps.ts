interface PokemonResults {
  name: string;
  url: string;
}
export default PokemonResults;
